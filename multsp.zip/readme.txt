Webtech Projekt my-ultimate-spendings

An diesem Projekt haben gearbeitet:
	Kesselbachert Max; 	0661454
	M��lacher Corinna; 	0960174
	Olschan Patrick; 	0960730
	
Arbeitsaufteilung ist im beigef�gten Excel-Sheet zu sehen. 
Bei Fehlern / Problemen hat aber jeder je nach Zeit an der geeigneten Stelle angepackt.

Im Ordner scripts ist ein Datenbank-Dump zu finden.
Im Ordner doc ist die von phpDocumentator erzeugte Dokumentation des application-Ordners abgelegt.

Zur Sourcecode-Verwaltung / -Versionierung liegt das Projekt auf github:
https://github.com/mkesselb/multsp

Hier auch der Link zum Webauftritt:
http://vm233-isys.aau.at/webtech3/multsp/public/   